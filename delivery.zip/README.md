
# Programming project

## Group elements

Identify all group elements (numbers and names).

- up201503035 Helder Bessa
- up201904710 Tomé Cunha


## Accomplished tasks

Implementamos para todos os elementos geométricos a leitura lógica e as suas respetivas classes.
Adicionamos os atributos id, transform e transfor_origin no cabeçalho.


